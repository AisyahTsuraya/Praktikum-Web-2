<?php
    include_once 'header.php';
    include_once 'sidebar.php'
?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <!DOCTYPE html>
<html lang="en">
    <head>
        <style>   
        </style>
        <meta charset="UTF-8" />
        <title>Curriculum Vitae</title>
    </head>
    <body style="margin: 0; background-color: #fff; letter-spacing: 0.0083em;">
        <div style="width: 100%; max-width: none;">
            <div style="display: flex; justify-content: space-between; align-items: flex-end;">
                <h1></h1>
                <ceenter><h2><u>Aisyah Tsuraya Rafilah</u></h2></ceenter>
                    <br>
            </div>
        </div>
        <section>
        <h2><u>Biodata</u></h2>
        <div>
                <p><b>NAMA : Aisyah Tsuraya Rafilah</p></b>
                <p><b>Tempat, Tanggal Lahir : Depok, 15 agustus 2003</p></b>
                <p><b>Jenis Kelamin : Perempuan</p></b>
                <p><b>Agama : Islam</p></b>
                <p><b>Pekerjaan : Mahasiswa</p></b>
                <p><b>Alamat : Jalan delima ujung l no 101 tanah baru beji , depok</p></b>
                
        </div>
    </section>

    <section>
        <h2><u>Pendidikan Terakhir</u></h2>
        <div>
            <ul>
                <li>
                <li>SDN 6 Mangunreja</li>
                <li>SMPN 3 Depok</li> 
                <li>SMAN 5 Depok</li>
                <li> Sistem Informasi STT NF</li>
            </ul>
        </div>
    </section>

    <section>
        <h2><u>Hobi</u></h2>
        <div>
            <p>Marketing, Travelling,Video games</p>
        </div>
    </section>
    <footer>
        <h2><u>Contact Me</u></h2>
        <div>
        <p><b>Instagram : Tsuraya_02</p></b>
        <p><b>Whatshapp : 081398719899</p></b>
        </div>
    </footer>
    </body>
</html>
    <!-- /.content -->
  </div>



    include_once'footer.php'
?>