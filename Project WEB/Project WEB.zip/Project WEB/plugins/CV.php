<!DOCTYPE html>
<html lang="en">
    <head>
        <style>   
        </style>
        <meta charset="UTF-8" />
        <title>Curriculum Vitae</title>
    </head>
    <body style="margin: 0; background-color: #fff; letter-spacing: 0.0083em;">
        <div style="width: 100%; max-width: none;">
            <div style="display: flex; justify-content: space-between; align-items: flex-end;">
                <h1></h1>
                <ceenter><h2><u>Aisyah Tsuraya Rafilah</u></h2></ceenter>
                    <br>
            </div>
        </div>

    <section>
        <h2><u>About Me</u></h2>
        <div>
            <p></p>Saya seorang yang kreatif dan suka mencari alternatif solusi dari berbagai macam persoalan. Saya juga bersikap terbuka terhadap semua kemungkinan solusi yang ada. Bagi saya, setiap pekerjaan adalah penting. Mengerjakannya dengan teliti dan semaksimal mungkin adalah bentuk tanggung jawab saya.Saya pun dikenal sebagai pendengar yang baik sehingga mampu menangkap inti persoalan dan memberikan solusi yang tepat.</p>
        </div>
    </section>

    <section>
        <h2><u>Education</u></h2>
        <div>
            <ul>
                <li>
                <li>SDN 6 Mangunreja</li>
                <li>SMPN 3 Depok</li> 
                <li>SMAN 5 Depok</li>
                <li> Sistem Informasi STT NF</li>
            </ul>
        </div>
    </section>
    <section>
        <h2><u>Interests</u></h2>
        <div>
            <p>Marketing, Travelling,Video games</p>
        </div>
    </section>
    <footer>
        <div>Contact Me</div>
        <div>
        <a href="instagram.com/tsuraya_02" target="_blank">Instagram</a>
        <a href="aistsuraya7@gmail.com" target="_blank">Email me</a>
        </div>
    </footer>
    </body>
</html>